import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HW9 {

    private static final String FILENAME = "grades.csv"; // 文件名

    public static void main(String[] args) {
        Map<String, Integer> grades = readFromFile(); // 从文件中读取成绩信息

        boolean isLoop = true;
        while (isLoop) {
            String line = input("請輸入指令選擇下列功能 0.新增 1.查詢 2.修改 3. 刪除 4.顯示所有 99. 結束：");
            String name;
            int grade;
            switch (line) {
                case "99":
                    isLoop = false;
                    break;
                case "0":
                    name = input("請輸入學生姓名:");
                    grade = Integer.parseInt(input("請輸入學生成績:"));
                    grades.putIfAbsent(name, grade);
                    break;
                case "1":
                    name = input("請輸入學生姓名:");
                    if (grades.containsKey(name)) {
                        System.out.println("學生姓名：" + name + " 成績：" + grades.get(name));
                    } else {
                        System.out.println("無此學生：" + name);
                    }
                    break;
                case "2":
                    name = input("請輸入學生姓名：");
                    if (grades.containsKey(name)) {
                        grade = Integer.parseInt(input("請輸入學生修改成績:"));
                        grades.put(name, grade);
                        System.out.println("學生姓名：" + name + " 修改後成績：" + grades.get(name));
                    } else {
                        System.out.println("無法修改成績，無此學生：" + name);
                    }
                    break;
                case "3":
                    name = input("請輸入學生姓名:");
                    if (grades.containsKey(name)) {
                        grades.remove(name);
                        System.out.println("學生姓名：" + name + "已刪除");
                    } else {
                        System.out.println("無法刪除，無此學生：" + name);
                    }
                    break;
                case "4":
                    System.out.println("學生成績列表:");
                    if (!grades.isEmpty()) {
                        for (Map.Entry<String, Integer> entry : grades.entrySet()) {
                            System.out.println(entry.getKey() + ": " + entry.getValue());
                        }
                    } else {
                        System.out.println("目前沒有學生成績記錄。");
                    }
                    break;
            }
        }

        writeToFile(grades); // 在程序结束时将成绩信息写入文件
    }

    static String input(String prompt) {
        System.out.print(prompt);
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }

    static Map<String, Integer> readFromFile() {
        Map<String, Integer> grades = new HashMap<>();
        File file = new File(FILENAME);
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(FILENAME))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    grades.put(parts[0], Integer.parseInt(parts[1]));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return grades;
    }

    static void writeToFile(Map<String, Integer> grades) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILENAME))) {
            for (Map.Entry<String, Integer> entry : grades.entrySet()) {
                bw.write(entry.getKey() + "," + entry.getValue());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
